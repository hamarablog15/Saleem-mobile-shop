SALEEM MOBILE SHOP - UDHAAR MANAGER (Android Studio project)

Shop details:
- Saleem Mobile Shop
- Owner: Qazi Muhammad Saleem Ali
- JazzCash / Easypaisa: 03038872889

Current starter features in source:
- Add customer and udhaar record manually
- Pick a customer from phone contacts using Android's contact picker
- Categories: Accessories / Transaction / Netcash
- Local SQLite storage for udhaar records
- Receive and record partial payments
- Summary of total udhaar, received, remaining, and overdue records
- JPEG receipt with shop watermark and share sheet (choose WhatsApp if installed)
- Udhaar and payment receipt flows
- One-time 10% overdue charge shown on receipts
- Simple illustrative credit score
- FileProvider configured for sharing receipt images

NOT YET COMPLETE / IMPORTANT:
- This ZIP is source code, NOT an installable APK.
- Google online backup is NOT implemented. To finish it, create a Firebase project, configure Google Sign-In and Firestore, add google-services.json, and implement authenticated syncing. Never share your Google password or private keys in chat.
- PIN lock, production-grade encryption, robust date validation, edit/delete tools, and automated tests still need implementation.
- Credit score is only a basic illustrative indicator, not a formal credit rating.
- Late charges are displayed as one-time 10% of the remaining balance when overdue. Confirm the agreed terms and applicable local rules before applying charges.

Build steps:
1. Install Android Studio on a computer.
2. Open this folder as a project and allow Gradle sync.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Test on a spare phone before using real customer data.

Package ID: pk.saleem.udhaar
Min Android version: Android 8.0 (API 26)

MOBILE-ONLY BUILD OPTION (GitHub Actions)
This project includes .github/workflows/android-apk.yml for a cloud build. It does not mean the APK is already built.
1. Create/sign in to a GitHub account.
2. Create a repository and upload the project files with the folder structure preserved (including the hidden .github/workflows/android-apk.yml file).
3. Open the repository's Actions tab, choose "Build Android APK", then tap "Run workflow".
4. When the run succeeds, open the run and download the artifact named "Saleem-Mobile-Shop-debug-apk". Extract it to get app-debug.apk, then install it on Android (allow installs from that source when prompted).
Note: Cloud build may fail if the source project has compilation issues; review the workflow logs and fix errors before installing. Google cloud backup is not configured in this starter project.
