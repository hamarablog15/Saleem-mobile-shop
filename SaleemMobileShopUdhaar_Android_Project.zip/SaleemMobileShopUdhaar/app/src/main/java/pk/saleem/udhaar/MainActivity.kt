package pk.saleem.udhaar

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var db: ShopDb
    private lateinit var root: LinearLayout
    private val shopName = "Saleem Mobile Shop"
    private val owner = "Qazi Muhammad Saleem Ali"
    private val shopPhone = "03038872889"
    private val purposes = arrayOf("Accessories", "Transaction", "Netcash")
    private var contactNameField: EditText? = null
    private var contactPhoneField: EditText? = null
    private val contactPickRequest = 4107

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ShopDb(this)
        showHome()
    }


    private fun showHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        root.addView(TextView(this).apply {
            text = shopName
            textSize = 25f
            setTextColor(Color.rgb(20, 70, 100))
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "$owner\nJazzCash / Easypaisa: $shopPhone"
            textSize = 15f
            setPadding(0, 6, 0, 20)
        })
        addButton("Add Udhaar / Customer") { addEntryDialog() }
        addButton("Customer & Udhaar Records") { showRecords() }
        addButton("Total Summary") { showSummary() }
        addButton("Google Backup Setup Guide") {
            AlertDialog.Builder(this)
                .setTitle("Google Backup")
                .setMessage("Cloud backup is not connected in this starter project. Firebase/Google sign-in must be configured with your own project credentials before online backup can work. See README.txt.")
                .setPositiveButton("OK", null).show()
        }
        setContentView(root)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false }
        root.addView(b, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 })
        b.setOnClickListener { action() }
    }

    private fun addEntryDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 8, 28, 0) }
        val name = EditText(this).apply { hint = "Customer name" }
        val phone = EditText(this).apply { hint = "Customer phone number"; inputType = 3 }
        contactNameField = name
        contactPhoneField = phone
        val chooseContact = Button(this).apply {
            text = "Choose from phone contacts"
            isAllCaps = false
            setOnClickListener {
                try {
                    val intent = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
                    startActivityForResult(intent, contactPickRequest)
                } catch (_: Exception) { toast("Contacts app is not available.") }
            }
        }
        val amount = EditText(this).apply { hint = "Udhaar amount (Rs.)"; inputType = 8194 }
        val start = EditText(this).apply { hint = "Start date (YYYY-MM-DD)"; setText(today()) }
        val due = EditText(this).apply { hint = "End / due date (YYYY-MM-DD)" }
        val purpose = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, purposes.toList()) }
        box.addView(chooseContact); box.addView(name); box.addView(phone); box.addView(amount); box.addView(start); box.addView(due); box.addView(purpose)
        AlertDialog.Builder(this).setTitle("New Udhaar")
            .setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim()
                val p = phone.text.toString().trim()
                val a = amount.text.toString().toDoubleOrNull()
                val s = start.text.toString().trim()
                val d = due.text.toString().trim()
                if (n.isBlank() || p.isBlank() || a == null || a <= 0 || d.isBlank()) {
                    toast("Please enter customer, phone, amount and due date.")
                } else {
                    val id = db.addEntry(n, p, purpose.selectedItem.toString(), a, s, d)
                    toast("Udhaar saved.")
                    AlertDialog.Builder(this)
                        .setTitle("Receipt")
                        .setMessage("Udhaar saved. Create JPEG receipt and share it on WhatsApp?")
                        .setNegativeButton("Later", null)
                        .setPositiveButton("Create & Share") { _, _ -> shareReceipt(id) }
                        .show()
                }
            }.show()
    }

    @Deprecated("Uses legacy activity result API for compatibility with the starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == contactPickRequest && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            var selectedName = ""
            var selectedPhone = ""
            contentResolver.query(uri, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID))
                    selectedName = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)) ?: ""
                    contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                        "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?", arrayOf(id), null)?.use { p ->
                        if (p.moveToFirst()) selectedPhone = p.getString(0) ?: ""
                    }
                }
            }
            contactNameField?.setText(selectedName)
            contactPhoneField?.setText(selectedPhone)
            if (selectedPhone.isBlank()) toast("Selected contact has no phone number.")
        }
    }

    private fun showRecords() {
        val entries = db.allEntries()
        if (entries.isEmpty()) { toast("No records yet."); return }
        val labels = entries.map {
            "${it.name} • ${it.phone}\nPurpose: ${it.purpose} | Original: Rs ${money(it.amount)} | Paid: Rs ${money(it.paid)} | Balance: Rs ${money(it.amount - it.paid)}\nDue: ${it.due}"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Udhaar Records")
            .setItems(labels) { _, which ->
                val e = entries[which]
                val options = arrayOf("Receive Payment", "Share Udhaar Receipt", "Share Payment Receipt")
                AlertDialog.Builder(this).setTitle(e.name).setItems(options) { _, action ->
                    when (action) {
                        0 -> receivePayment(e.id, e.amount - e.paid)
                        1 -> shareReceipt(e.id)
                        2 -> receivePayment(e.id, e.amount - e.paid, shareAfter = true)
                    }
                }.show()
            }.setPositiveButton("Close", null).show()
    }

    private fun receivePayment(id: Long, balance: Double, shareAfter: Boolean = false) {
        if (balance <= 0) { toast("No balance remaining."); return }
        val input = EditText(this).apply { hint = "Payment received (Rs.)"; inputType = 8194 }
        AlertDialog.Builder(this).setTitle("Receive Payment").setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val paid = input.text.toString().toDoubleOrNull()
                if (paid == null || paid <= 0 || paid > balance) {
                    toast("Enter a valid amount up to Rs ${money(balance)}.")
                } else {
                    db.addPayment(id, paid)
                    toast("Payment saved.")
                    if (shareAfter) shareReceipt(id, paymentReceipt = true)
                    else AlertDialog.Builder(this).setMessage("Payment saved. Share payment receipt?")
                        .setNegativeButton("Later", null)
                        .setPositiveButton("Share") { _, _ -> shareReceipt(id, paymentReceipt = true) }.show()
                }
            }.show()
    }

    private fun showSummary() {
        val all = db.allEntries()
        val total = all.sumOf { it.amount }
        val paid = all.sumOf { it.paid }
        val late = all.count { it.amount > it.paid && it.due < today() }
        AlertDialog.Builder(this).setTitle("Shop Summary")
            .setMessage("Total Udhaar: Rs ${money(total)}\nTotal Received: Rs ${money(paid)}\nRemaining Balance: Rs ${money(total-paid)}\nOverdue customers: $late\n\nLate charge rule: one-time 10% after due date. This starter version shows the rule; verify charges before collecting.")
            .setPositiveButton("OK", null).show()
    }

    private fun shareReceipt(id: Long, paymentReceipt: Boolean = false) {
        val e = db.getEntry(id) ?: return
        val balance = (e.amount - e.paid).coerceAtLeast(0.0)
        val late = e.due < today() && balance > 0
        val lateCharge = if (late) balance * 0.10 else 0.0
        val title = if (paymentReceipt) "PAYMENT RECEIPT" else "UDHAAR RECEIPT"
        val lines = listOf(
            shopName, owner, "JazzCash / Easypaisa: $shopPhone", "",
            title, "Receipt No: SM-${e.id}", "Date: ${today()}", "",
            "Customer: ${e.name}", "Phone: ${e.phone}", "Purpose: ${e.purpose}",
            "Start Date: ${e.start}", "Due Date: ${e.due}", "",
            "Original Udhaar: Rs ${money(e.amount)}", "Paid Amount: Rs ${money(e.paid)}",
            "Remaining Balance: Rs ${money(balance)}",
            "One-time 10% late charge (if overdue): Rs ${money(lateCharge)}",
            "Total Due incl. late charge: Rs ${money(balance + lateCharge)}", "",
            "Credit Score: ${creditScore(e)} / 100", "",
            "Late payment ki surat mein due date ke baad baqi raqam par ek martaba 10% charges hon ge.",
            "", "Thank you!"
        )
        try {
            val bmp = makeReceipt(lines)
            val dir = File(cacheDir, "receipts").apply { mkdirs() }
            val file = File(dir, "Saleem_Receipt_${e.id}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            val uri = androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.fileprovider", file
            )
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Saleem Mobile Shop receipt")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Share receipt"))
        } catch (ex: Exception) {
            // FileProvider configuration is included in README; fallback gives useful diagnostic.
            toast("Receipt share setup needs FileProvider configuration. See README.txt.")
        }
    }

    private fun makeReceipt(lines: List<String>): Bitmap {
        val width = 900
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 30f }
        val lineHeight = 48
        val bmp = Bitmap.createBitmap(width, maxOf(1200, 120 + lines.size * lineHeight), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val watermark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(235, 239, 242); textSize = 68f; typeface = Typeface.DEFAULT_BOLD
        }
        canvas.save()
        canvas.rotate(-28f, width / 2f, bmp.height / 2f)
        canvas.drawText("SALEEM MOBILE SHOP", 70f, bmp.height / 2f, watermark)
        canvas.restore()
        var y = 70f
        lines.forEachIndexed { i, line ->
            paint.textSize = when (i) { 0 -> 42f; 1 -> 26f; 4 -> 36f; else -> 27f }
            paint.typeface = if (i == 0 || i == 4) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            if (line.isNotEmpty()) canvas.drawText(line.take(48), 40f, y, paint)
            y += if (line.isEmpty()) 25f else lineHeight.toFloat()
        }
        return bmp
    }

    private fun creditScore(e: Entry): Int {
        if (e.paid <= 0.0) return 50
        val ratio = (e.paid / e.amount).coerceIn(0.0, 1.0)
        val overduePenalty = if (e.due < today() && e.paid < e.amount) 15 else 0
        return (50 + (ratio * 50).roundToInt() - overduePenalty).coerceIn(0, 100)
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun money(v: Double) = String.format(Locale.US, "%,.2f", v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

data class Entry(
    val id: Long, val name: String, val phone: String, val purpose: String,
    val amount: Double, val paid: Double, val start: String, val due: String
)

class ShopDb(context: android.content.Context) : SQLiteOpenHelper(context, "saleem_udhaar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL,
            purpose TEXT NOT NULL, amount REAL NOT NULL, paid REAL NOT NULL DEFAULT 0,
            start_date TEXT NOT NULL, due_date TEXT NOT NULL)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addEntry(name: String, phone: String, purpose: String, amount: Double, start: String, due: String): Long {
        val cv = ContentValues().apply {
            put("name", name); put("phone", phone); put("purpose", purpose)
            put("amount", amount); put("paid", 0.0); put("start_date", start); put("due_date", due)
        }
        return writableDatabase.insert("entries", null, cv)
    }
    fun addPayment(id: Long, amount: Double) {
        writableDatabase.execSQL("UPDATE entries SET paid = paid + ? WHERE id = ?", arrayOf(amount, id))
    }
    fun allEntries(): List<Entry> {
        val c = readableDatabase.rawQuery("SELECT id,name,phone,purpose,amount,paid,start_date,due_date FROM entries ORDER BY id DESC", null)
        val out = mutableListOf<Entry>()
        c.use { while (it.moveToNext()) out.add(Entry(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getDouble(4), it.getDouble(5), it.getString(6), it.getString(7))) }
        return out
    }
    fun getEntry(id: Long): Entry? = allEntries().firstOrNull { it.id == id }
}
